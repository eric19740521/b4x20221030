package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class xyzlinenotify extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.xyzlinenotify", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.xyzlinenotify.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _lineurl = "";
public boolean _isshowlog = false;
public String _linetoken = "";
public String _errormessage = "";
public b4j.example.main _main = null;
public b4j.example.httputils2service _httputils2service = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 5;BA.debugLine="Private LineUrl As String = \"https://notify-api.l";
_lineurl = "https://notify-api.line.me/api/notify";
 //BA.debugLineNum = 7;BA.debugLine="Public IsShowLog As Boolean = False";
_isshowlog = __c.False;
 //BA.debugLineNum = 8;BA.debugLine="Private LineToken As String = \"\"";
_linetoken = "";
 //BA.debugLineNum = 9;BA.debugLine="Public ErrorMessage As String = \"\"";
_errormessage = "";
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,String _token) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Initialize(token As String)";
 //BA.debugLineNum = 19;BA.debugLine="LineToken = token";
_linetoken = _token;
 //BA.debugLineNum = 20;BA.debugLine="ErrorMessage = \"\"";
_errormessage = "";
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _sendmessage(String _text) throws Exception{
ResumableSub_SendMessage rsub = new ResumableSub_SendMessage(this,_text);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_SendMessage extends BA.ResumableSub {
public ResumableSub_SendMessage(b4j.example.xyzlinenotify parent,String _text) {
this.parent = parent;
this._text = _text;
}
b4j.example.xyzlinenotify parent;
String _text;
boolean _isok = false;
b4j.example.httpjob _job = null;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 41;BA.debugLine="Dim IsOK As Boolean = False";
_isok = parent.__c.False;
 //BA.debugLineNum = 42;BA.debugLine="Dim job As HttpJob";
_job = new b4j.example.httpjob();
 //BA.debugLineNum = 44;BA.debugLine="If Text = Null Or Text = \"\" Then	'都沒有傳資料時";
if (true) break;

case 1:
//if
this.state = 4;
if (_text== null || (_text).equals("")) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 45;BA.debugLine="ErrorMessage = $\"Text = Null Or Text = \"\"\"$";
parent._errormessage = ("Text = Null Or Text = \"\"");
 //BA.debugLineNum = 46;BA.debugLine="Return IsOK";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_isok));return;};
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 49;BA.debugLine="job.Initialize(\"\",Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 50;BA.debugLine="job.PostString(LineUrl,$\"message=${Text}\"$)";
_job._poststring /*String*/ (parent._lineurl,("message="+parent.__c.SmartStringFormatter("",(Object)(_text))+""));
 //BA.debugLineNum = 51;BA.debugLine="job.GetRequest.SetHeader(\"Authorization\", $\"Beare";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Authorization",("Bearer "+parent.__c.SmartStringFormatter("",(Object)(parent._linetoken))+""));
 //BA.debugLineNum = 52;BA.debugLine="job.GetRequest.SetContentType(\"application/x-www-";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("application/x-www-form-urlencoded");
 //BA.debugLineNum = 53;BA.debugLine="Wait For (job) JobDone(j As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 11;
return;
case 11:
//C
this.state = 5;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 54;BA.debugLine="If j.Success Then";
if (true) break;

case 5:
//if
this.state = 10;
if (_j._success /*boolean*/ ) { 
this.state = 7;
}else {
this.state = 9;
}if (true) break;

case 7:
//C
this.state = 10;
 //BA.debugLineNum = 56;BA.debugLine="IsOK = True";
_isok = parent.__c.True;
 //BA.debugLineNum = 57;BA.debugLine="ErrorMessage = \"\"";
parent._errormessage = "";
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 60;BA.debugLine="ErrorMessage = j.ErrorMessage";
parent._errormessage = _j._errormessage /*String*/ ;
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 63;BA.debugLine="Return IsOK";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_isok));return;};
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _jobdone(b4j.example.httpjob _j) throws Exception{
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _sendmessage2(anywheresoftware.b4a.objects.collections.Map _data,b4j.example.httpjob._multipartfiledata _fd) throws Exception{
ResumableSub_SendMessage2 rsub = new ResumableSub_SendMessage2(this,_data,_fd);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_SendMessage2 extends BA.ResumableSub {
public ResumableSub_SendMessage2(b4j.example.xyzlinenotify parent,anywheresoftware.b4a.objects.collections.Map _data,b4j.example.httpjob._multipartfiledata _fd) {
this.parent = parent;
this._data = _data;
this._fd = _fd;
}
b4j.example.xyzlinenotify parent;
anywheresoftware.b4a.objects.collections.Map _data;
b4j.example.httpjob._multipartfiledata _fd;
boolean _isok = false;
b4j.example.httpjob _job = null;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 82;BA.debugLine="Dim IsOK As Boolean = False";
_isok = parent.__c.False;
 //BA.debugLineNum = 83;BA.debugLine="Dim job As HttpJob";
_job = new b4j.example.httpjob();
 //BA.debugLineNum = 86;BA.debugLine="If data = Null And fd = Null Then	'都沒有傳資料時";
if (true) break;

case 1:
//if
this.state = 4;
if (_data== null && _fd== null) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 87;BA.debugLine="ErrorMessage = \"data = Null And fd = Null\"";
parent._errormessage = "data = Null And fd = Null";
 //BA.debugLineNum = 88;BA.debugLine="Return IsOK";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_isok));return;};
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 91;BA.debugLine="job.Initialize(\"image\", Me)";
_job._initialize /*String*/ (ba,"image",parent);
 //BA.debugLineNum = 93;BA.debugLine="Try";
if (true) break;

case 5:
//try
this.state = 20;
this.catchState = 19;
this.state = 7;
if (true) break;

case 7:
//C
this.state = 8;
this.catchState = 19;
 //BA.debugLineNum = 95;BA.debugLine="If data.IsInitialized = True And fd <> Null Then";
if (true) break;

case 8:
//if
this.state = 11;
if (_data.IsInitialized()==parent.__c.True && _fd!= null) { 
this.state = 10;
}if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 96;BA.debugLine="job.PostMultipart(LineUrl,data,Array(fd))";
_job._postmultipart /*String*/ (parent._lineurl,_data,anywheresoftware.b4a.keywords.Common.ArrayToList(new Object[]{(Object)(_fd)}));
 if (true) break;
;
 //BA.debugLineNum = 98;BA.debugLine="If data.IsInitialized = True And fd = Null Then";

case 11:
//if
this.state = 14;
if (_data.IsInitialized()==parent.__c.True && _fd== null) { 
this.state = 13;
}if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 99;BA.debugLine="job.PostMultipart(LineUrl,data,Null)";
_job._postmultipart /*String*/ (parent._lineurl,_data,(anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(parent.__c.Null)));
 if (true) break;
;
 //BA.debugLineNum = 101;BA.debugLine="If data.IsInitialized = False And fd <> Null The";

case 14:
//if
this.state = 17;
if (_data.IsInitialized()==parent.__c.False && _fd!= null) { 
this.state = 16;
}if (true) break;

case 16:
//C
this.state = 17;
 //BA.debugLineNum = 106;BA.debugLine="data.Initialize";
_data.Initialize();
 //BA.debugLineNum = 107;BA.debugLine="data.Put(\"message\",\".\")		'用.點代替";
_data.Put((Object)("message"),(Object)("."));
 //BA.debugLineNum = 109;BA.debugLine="job.PostMultipart(LineUrl,data,Array(fd))";
_job._postmultipart /*String*/ (parent._lineurl,_data,anywheresoftware.b4a.keywords.Common.ArrayToList(new Object[]{(Object)(_fd)}));
 if (true) break;

case 17:
//C
this.state = 20;
;
 if (true) break;

case 19:
//C
this.state = 20;
this.catchState = 0;
 //BA.debugLineNum = 113;BA.debugLine="ErrorMessage = LastException";
parent._errormessage = BA.ObjectToString(parent.__c.LastException(ba));
 //BA.debugLineNum = 114;BA.debugLine="Return IsOK";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_isok));return;};
 if (true) break;
if (true) break;

case 20:
//C
this.state = 21;
this.catchState = 0;
;
 //BA.debugLineNum = 119;BA.debugLine="job.GetRequest.SetHeader(\"Content-Type\",\"multipar";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Content-Type","multipart/form-data");
 //BA.debugLineNum = 120;BA.debugLine="job.GetRequest.SetHeader(\"Authorization\",$\"Bearer";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Authorization",("Bearer "+parent.__c.SmartStringFormatter("",(Object)(parent._linetoken))+""));
 //BA.debugLineNum = 121;BA.debugLine="Wait For (job) JobDone(j As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 27;
return;
case 27:
//C
this.state = 21;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 122;BA.debugLine="If j.Success Then";
if (true) break;

case 21:
//if
this.state = 26;
if (_j._success /*boolean*/ ) { 
this.state = 23;
}else {
this.state = 25;
}if (true) break;

case 23:
//C
this.state = 26;
 //BA.debugLineNum = 124;BA.debugLine="IsOK = True";
_isok = parent.__c.True;
 //BA.debugLineNum = 125;BA.debugLine="ErrorMessage = \"\"";
parent._errormessage = "";
 if (true) break;

case 25:
//C
this.state = 26;
 //BA.debugLineNum = 128;BA.debugLine="ErrorMessage = j.ErrorMessage";
parent._errormessage = _j._errormessage /*String*/ ;
 if (true) break;

case 26:
//C
this.state = -1;
;
 //BA.debugLineNum = 131;BA.debugLine="Return IsOK";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_isok));return;};
 //BA.debugLineNum = 132;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public String  _systemlog(String _text) throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Public Sub SystemLog(Text As String)";
 //BA.debugLineNum = 25;BA.debugLine="If IsShowLog Then";
if (_isshowlog) { 
 //BA.debugLineNum = 27;BA.debugLine="LogColor(Text,0xFF0856EF)";
__c.LogImpl("33145731",_text,((int)0xff0856ef));
 };
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
