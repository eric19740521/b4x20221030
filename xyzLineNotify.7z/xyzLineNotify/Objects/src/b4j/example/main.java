package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static b4j.example.httputils2service _httputils2service = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 13;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 14;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 15;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 16;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public static void  _button1_click() throws Exception{
ResumableSub_Button1_Click rsub = new ResumableSub_Button1_Click(null);
rsub.resume(ba, null);
}
public static class ResumableSub_Button1_Click extends BA.ResumableSub {
public ResumableSub_Button1_Click(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
String _token = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _url = null;
b4j.example.httpjob._multipartfiledata _fd = null;
anywheresoftware.b4a.objects.collections.Map _data = null;
b4j.example.httpjob _job1 = null;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 21;BA.debugLine="SendMessageToLine(\"Hello\")";
_sendmessagetoline("Hello");
 //BA.debugLineNum = 22;BA.debugLine="SendMessageToLine(\"歡迎,B4X\")";
_sendmessagetoline("歡迎,B4X");
 //BA.debugLineNum = 25;BA.debugLine="Dim token As String = \"hbLgKnUN80g5pe4apA0bt2vtKm";
_token = "hbLgKnUN80g5pe4apA0bt2vtKmpPxhGVQlMhOhV2AUK";
 //BA.debugLineNum = 27;BA.debugLine="Dim url As StringBuilder";
_url = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 28;BA.debugLine="url.Initialize";
_url.Initialize();
 //BA.debugLineNum = 29;BA.debugLine="url.Append($\"https://notify-api.line.me/api/notif";
_url.Append(("https://notify-api.line.me/api/notify"));
 //BA.debugLineNum = 31;BA.debugLine="Dim fd As MultipartFileData";
_fd = new b4j.example.httpjob._multipartfiledata();
 //BA.debugLineNum = 32;BA.debugLine="fd.Initialize";
_fd.Initialize();
 //BA.debugLineNum = 33;BA.debugLine="fd.KeyName=\"imageFile\"";
_fd.KeyName /*String*/  = "imageFile";
 //BA.debugLineNum = 34;BA.debugLine="fd.Dir = $\"d:\\\"$";
_fd.Dir /*String*/  = ("d:\\");
 //BA.debugLineNum = 35;BA.debugLine="fd.FileName = \"1.jpg\"";
_fd.FileName /*String*/  = "1.jpg";
 //BA.debugLineNum = 36;BA.debugLine="fd.ContentType = \"image/png\"";
_fd.ContentType /*String*/  = "image/png";
 //BA.debugLineNum = 38;BA.debugLine="Dim data As Map";
_data = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 39;BA.debugLine="data.Initialize";
_data.Initialize();
 //BA.debugLineNum = 40;BA.debugLine="data.Put(\"message\",\"B4X!!測試LINE訊息\")";
_data.Put((Object)("message"),(Object)("B4X!!測試LINE訊息"));
 //BA.debugLineNum = 41;BA.debugLine="data.Put(\"message\",\"B4X!!很好用\")";
_data.Put((Object)("message"),(Object)("B4X!!很好用"));
 //BA.debugLineNum = 42;BA.debugLine="data.Put(\"stickerPackageId\",\"446\")";
_data.Put((Object)("stickerPackageId"),(Object)("446"));
 //BA.debugLineNum = 43;BA.debugLine="data.Put(\"stickerId\",\"1988\")";
_data.Put((Object)("stickerId"),(Object)("1988"));
 //BA.debugLineNum = 45;BA.debugLine="Dim job1 As HttpJob";
_job1 = new b4j.example.httpjob();
 //BA.debugLineNum = 46;BA.debugLine="job1.Initialize(\"image\", Me)";
_job1._initialize /*String*/ (ba,"image",main.getObject());
 //BA.debugLineNum = 47;BA.debugLine="job1.PostMultipart(url.ToString,data,Array(fd))";
_job1._postmultipart /*String*/ (_url.ToString(),_data,anywheresoftware.b4a.keywords.Common.ArrayToList(new Object[]{(Object)(_fd)}));
 //BA.debugLineNum = 48;BA.debugLine="job1.GetRequest.SetHeader(\"Content-Type\",\"multipa";
_job1._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Content-Type","multipart/form-data");
 //BA.debugLineNum = 49;BA.debugLine="job1.GetRequest.SetHeader(\"Authorization\",$\"Beare";
_job1._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Authorization",("Bearer "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_token))+""));
 //BA.debugLineNum = 51;BA.debugLine="Wait For (job1) JobDone(j As HttpJob)";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, this, (Object)(_job1));
this.state = 7;
return;
case 7:
//C
this.state = 1;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 52;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 6;
if (_j._success /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 53;BA.debugLine="Log(\" Success: \"&j.GetString)";
anywheresoftware.b4a.keywords.Common.LogImpl("3131106"," Success: "+_j._getstring /*String*/ (),0);
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 56;BA.debugLine="Log(\" Failed:\"&j.ErrorMessage)";
anywheresoftware.b4a.keywords.Common.LogImpl("3131109"," Failed:"+_j._errormessage /*String*/ ,0);
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _jobdone(b4j.example.httpjob _j) throws Exception{
}
public static void  _button2_click() throws Exception{
ResumableSub_Button2_Click rsub = new ResumableSub_Button2_Click(null);
rsub.resume(ba, null);
}
public static class ResumableSub_Button2_Click extends BA.ResumableSub {
public ResumableSub_Button2_Click(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
b4j.example.xyzlinenotify _line = null;
boolean _success = false;
b4j.example.httpjob._multipartfiledata _fd = null;
anywheresoftware.b4a.objects.collections.Map _data = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 82;BA.debugLine="Dim line As xyzLINENotify";
_line = new b4j.example.xyzlinenotify();
 //BA.debugLineNum = 84;BA.debugLine="line.Initialize(\"hbLgKnUN80g5pe4apA0bt2vtKmpPxhGV";
_line._initialize /*String*/ (ba,"hbLgKnUN80g5pe4apA0bt2vtKmpPxhGVQlMhOhV2AUK");
 //BA.debugLineNum = 85;BA.debugLine="line.IsShowLog = True";
_line._isshowlog /*boolean*/  = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 88;BA.debugLine="Wait For (line.SendMessage(\"HI,今天好嗎???\")) complet";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _line._sendmessage /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("HI,今天好嗎???"));
this.state = 11;
return;
case 11:
//C
this.state = 1;
_success = (boolean) result[0];
;
 //BA.debugLineNum = 89;BA.debugLine="If Success = False Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_success==anywheresoftware.b4a.keywords.Common.False) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 90;BA.debugLine="Log($\"lineNotify fail:${line.ErrorMessage}\"$)";
anywheresoftware.b4a.keywords.Common.LogImpl("32621449",("lineNotify fail:"+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_line._errormessage /*String*/ ))+""),0);
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 95;BA.debugLine="Dim fd As MultipartFileData";
_fd = new b4j.example.httpjob._multipartfiledata();
 //BA.debugLineNum = 96;BA.debugLine="fd.Initialize";
_fd.Initialize();
 //BA.debugLineNum = 97;BA.debugLine="fd.KeyName=\"imageFile\"";
_fd.KeyName /*String*/  = "imageFile";
 //BA.debugLineNum = 98;BA.debugLine="fd.Dir = $\"d:\\\"$";
_fd.Dir /*String*/  = ("d:\\");
 //BA.debugLineNum = 99;BA.debugLine="fd.FileName = \"2022-10-16_155407.jpg\"";
_fd.FileName /*String*/  = "2022-10-16_155407.jpg";
 //BA.debugLineNum = 100;BA.debugLine="fd.ContentType = \"image/png\"";
_fd.ContentType /*String*/  = "image/png";
 //BA.debugLineNum = 103;BA.debugLine="Dim data As Map";
_data = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 104;BA.debugLine="data.Initialize";
_data.Initialize();
 //BA.debugLineNum = 105;BA.debugLine="data.Put(\"message\",\"B4X!!測試LINE訊息\")";
_data.Put((Object)("message"),(Object)("B4X!!測試LINE訊息"));
 //BA.debugLineNum = 109;BA.debugLine="Wait For (line.SendMessage2(Null,fd)) complete (S";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _line._sendmessage2 /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(anywheresoftware.b4a.keywords.Common.Null)),_fd));
this.state = 12;
return;
case 12:
//C
this.state = 5;
_success = (boolean) result[0];
;
 //BA.debugLineNum = 110;BA.debugLine="If Success = False Then";
if (true) break;

case 5:
//if
this.state = 10;
if (_success==anywheresoftware.b4a.keywords.Common.False) { 
this.state = 7;
}else {
this.state = 9;
}if (true) break;

case 7:
//C
this.state = 10;
 //BA.debugLineNum = 111;BA.debugLine="Log($\"lineNotify fail:${line.ErrorMessage}\"$)";
anywheresoftware.b4a.keywords.Common.LogImpl("32621470",("lineNotify fail:"+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_line._errormessage /*String*/ ))+""),0);
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 113;BA.debugLine="xui.MsgboxAsync(\"OK\",\"B4X\")";
parent._xui.MsgboxAsync(ba,"OK","B4X");
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _complete(boolean _success) throws Exception{
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
httputils2service._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public static String  _sendmessagetoline(String _text) throws Exception{
b4j.example.httpjob _http = null;
String _url = "";
 //BA.debugLineNum = 64;BA.debugLine="Sub SendMessageToLine(Text As String)";
 //BA.debugLineNum = 66;BA.debugLine="Dim http As HttpJob";
_http = new b4j.example.httpjob();
 //BA.debugLineNum = 67;BA.debugLine="Dim url As String";
_url = "";
 //BA.debugLineNum = 68;BA.debugLine="url = \"https://notify-api.line.me/api/notify\"";
_url = "https://notify-api.line.me/api/notify";
 //BA.debugLineNum = 69;BA.debugLine="http.Initialize(\"\",Me)";
_http._initialize /*String*/ (ba,"",main.getObject());
 //BA.debugLineNum = 70;BA.debugLine="http.PostString(url,$\"message=${Text}\"$)";
_http._poststring /*String*/ (_url,("message="+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_text))+""));
 //BA.debugLineNum = 71;BA.debugLine="http.GetRequest.SetHeader(\"Authorization\", \"Beare";
_http._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Authorization","Bearer hbLgKnUN80g5pe4apA0bt2vtKmpPxhGVQlMhOhV2AUK");
 //BA.debugLineNum = 72;BA.debugLine="http.GetRequest.SetContentType(\"application/x-www";
_http._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("application/x-www-form-urlencoded");
 //BA.debugLineNum = 75;BA.debugLine="End Sub";
return "";
}
}
